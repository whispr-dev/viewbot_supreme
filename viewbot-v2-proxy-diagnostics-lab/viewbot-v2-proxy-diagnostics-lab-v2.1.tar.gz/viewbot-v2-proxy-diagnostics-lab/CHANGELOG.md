# Changelog

## v2.1 — proxy diagnostics hardening + self-infra blackbox probing

### proxy_tester
- SOCKS4 and SOCKS5 supported end-to-end (was URL-routed only).
- Per-proxy retry budget with exponential backoff and full jitter
  (`--max-retries`, `--retry-backoff-base`, `--retry-backoff-cap`).
- TLS handshake capture (version, cipher, peer subject CN) on HTTPS
  reflectors, surfaced in the per-result JSON and on `ProxyResult.tls`.
- IPv6 hosts handled in the parser (bracketed literals, e.g.
  `socks5://[2001:db8::1]:1080`) and re-bracketed at URL composition.
- Aggregate output now includes `latency_summary_ms` (p50/p90/p95/p99),
  `working_by_scheme`, and `working_by_anonymity` blocks.
- `--seed` makes backoff jitter deterministic for reproducible runs.

### proxy_pool
- EWMA latency scoring replaces the ad-hoc weight multiplier; alpha
  tunable via `PoolConfig.ewma_alpha`.
- Per-proxy circuit breaker (CLOSED → OPEN → HALF_OPEN) with configurable
  failure threshold, reset timeout, and half-open probe cap. Open breakers
  remove proxies from the candidate set entirely.
- Pluggable selection strategies (`pool_strategies.py`):
  `weighted_random`, `round_robin`, `sticky`, `lowest_latency`.
- Laplace-smoothed success rate factored into score so fresh proxies
  aren't penalised before they have data.
- Graceful degradation: `choose()` returns `None` when the pool is
  depleted; callers handle the fallback.
- `pool-report` and `run-lab` accept all of these via new flags.

### Adapters and lab runner
- New `health_probe.py`: generic HTTP health probe with retry budget,
  assertion suite (status range, max latency, body substring, JSON key
  path, header presence), and best-effort TLS info pull.
- New `infra.py`: declarative inventory of legitimate infrastructure
  targets — Litehaus beacon nodes (Mars, NYC, London, Sydney, Singapore),
  FastPing.it `/probe`, mars-api `/health`, mail.whispr.dev, 80days.site.
  Edit the URLs in one place to match your live endpoints.
- New `adapters.py` classes: `SingleTargetProbeAdapter`, `LitehausFleetAdapter`.
  Original `LocalEchoAdapter` preserved for simulation runs.
- `lab_runner` now handles sync *and* async adapters via the
  `is_async` flag; feeds observed latency back into the pool's EWMA.

### New CLI command: `probe-infra`
Blackbox-style probing of the declared inventory. Supports
`--category`/`--name` filters, concurrency control, and optional pool
routing for "probe self-infra through a tested proxy set".
Output JSON includes per-target outcomes, by-category roll-ups, and an
overall latency summary.

### Tests
27 tests pass:
- `test_percentiles.py` — nearest-rank semantics, edge cases.
- `test_circuit_breaker.py` — full state machine coverage.
- `test_pool_strategies.py` — weighted distribution, round-robin cursor
  survival, sticky key binding + rebind on health loss, lowest-latency.
- `test_proxy_parser.py` — preserved from v2.0, still green after the
  IPv6 regex rework.
