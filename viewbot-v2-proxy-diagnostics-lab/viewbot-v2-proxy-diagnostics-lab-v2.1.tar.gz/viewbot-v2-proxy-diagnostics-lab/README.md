# viewbot-lab — proxy diagnostics + self-infra blackbox probing

Async Python lab for two related jobs:

1. **Test a proxy list** against an allow-listed reflector
   (`httpbin.org/anything` by default) — full SOCKS4/5/HTTP(S) support,
   IPv6, latency percentiles, retry budget, TLS handshake capture,
   anonymity classification.

2. **Probe your own infrastructure** — declared once in `infra.py`,
   exercised via the `probe-infra` CLI or as part of a lab run. Designed
   for self-owned services (Litehaus beacon nodes, FastPing.it `/probe`,
   mars-api `/health`, mail.whispr.dev, 80days.site).

Targets are restricted by the safety allow-list in `safety.py`. Adding
more reflectors or infra targets is a one-file edit.

---

## Install

```bash
python -m pip install -r requirements.txt
```

## Quickstart

### Test a proxy list

```bash
python -m viewbot_lab test-proxies \
    -i sample-proxies.txt \
    --json-output proxy-results.json \
    --max-retries 2 \
    --concurrency 50
```

Output JSON now includes a `latency_summary_ms` block with p50/p90/p95/p99
plus `working_by_scheme` and `working_by_anonymity` roll-ups.

### Inspect the pool

```bash
python -m viewbot_lab pool-report \
    --results proxy-results.json \
    --strategy weighted_random \
    --ewma-alpha 0.2 \
    --breaker-threshold 5
```

Reports per-breaker-state counts (closed / open / half_open), median EWMA
latency, and the active strategy.

### Probe your own infrastructure

```bash
python -m viewbot_lab probe-infra \
    --category litehaus,fastping \
    --concurrency 8 \
    -o infra-probe-results.json
```

Or sweep everything declared in the inventory:

```bash
python -m viewbot_lab probe-infra -o infra-probe-results.json
```

Optionally route the probes through your tested proxy pool (useful when
you want to verify a service is reachable *from a third-party network
egress*, not just from your own host):

```bash
python -m viewbot_lab probe-infra \
    --use-pool \
    --pool-results proxy-results.json \
    --pool-strategy sticky \
    -o infra-probe-results.json
```

### Run a lab event sweep

```bash
# Local simulation only (no external requests):
python -m viewbot_lab run-lab --adapter local_echo --events 50

# Live blackbox sweep through the pool, one event = one Litehaus fleet check:
python -m viewbot_lab run-lab \
    --adapter litehaus_fleet \
    --strategy round_robin \
    --events 100
```

---

## Adapter inventory

Selected via `--adapter` on `run-lab`:

| Name              | What it does                                         |
|-------------------|------------------------------------------------------|
| `local_echo`      | Local-only simulation; no external requests          |
| `litehaus_beacon` | Single-node Litehaus `/ping` (Mars by default)       |
| `litehaus_fleet`  | All Litehaus `/ping` endpoints in parallel per event |
| `fastping_probe`  | `GET https://fastping.it.com/probe`                  |
| `mars_api_health` | `GET https://mars.litehaus.example/health`           |
| `mail_whispr`     | `GET https://mail.whispr.dev/`                       |
| `eightydays`      | `GET https://80days.site/`                           |

URLs are placeholders that match the layout in your operational notes —
edit them to the real endpoints in `src/viewbot_lab/infra.py`. Every
target's assertion config (max latency, required JSON key, etc.) lives
on the `HttpProbeRequest` next to its URL, so one file holds the entire
contract.

---

## Pool selection strategies

| Name              | When to use                                          |
|-------------------|------------------------------------------------------|
| `weighted_random` | Default — spreads load, favours fast/healthy proxies |
| `round_robin`     | Deterministic load spreading across equivalents      |
| `sticky`          | A given key always lands on the same proxy when healthy |
| `lowest_latency`  | Greedy — picks the fastest proxy by EWMA             |

All four interact correctly with the per-proxy circuit breaker: an open
breaker removes a candidate from the strategy's view entirely.

---

## Run the tests

```bash
PYTHONPATH=src python -m pytest tests/ -v
```

Should show **27 passed** covering percentiles, breaker state machine,
strategies, and the proxy parser.

---

## Layout

```
src/viewbot_lab/
    adapters.py          adapter implementations (local + real)
    circuit_breaker.py   three-state breaker for per-proxy health
    cli.py               argparse + command registry
    config.py            frozen config dataclasses
    health_probe.py      generic HTTP health probe core
    infra.py             declarative inventory of self-owned targets
    io_utils.py          atomic file writers
    lab_runner.py        event-driven runner (sync + async adapters)
    percentiles.py       nearest-rank latency stats
    pool_strategies.py   weighted_random / round_robin / sticky / lowest_latency
    probe_runner.py      backend for the probe-infra CLI command
    proxy_models.py      ProxyEntry, ProxyResult, TlsHandshakeInfo
    proxy_parser.py      IPv6-aware proxy list parser
    proxy_pool.py        EWMA + breaker + strategy-driven pool
    proxy_tester.py      concurrent reflector test runner
    registry.py          command name → handler map
    safety.py            reflector allow-list + platform block-list
tests/
    test_circuit_breaker.py
    test_percentiles.py
    test_pool_strategies.py
    test_proxy_parser.py
```
